/* Profile Toggle */
function menuToggle() {
    const toggleMenu = document.querySelector(".profilemenu");
    toggleMenu.classList.toggle("open");
}

/* Side Navbar */
document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId),
            bodypd = document.getElementById(bodyId),
            headerpd = document.getElementById(headerId);

        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
                // show navbar
                nav.classList.toggle('show');
                // change icon
                toggle.classList.toggle('bx-x');
                // add padding to body
                bodypd.classList.toggle('body-pd');
                // add padding to header
                headerpd.classList.toggle('body-pd');
            });
        }
    };

    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header');

    /*===== LINK ACTIVE =====*/
    const linkColor = document.querySelectorAll('.nav_link');

    function colorLink() {
        if (linkColor) {
            linkColor.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        }
    }

    linkColor.forEach(l => l.addEventListener('click', colorLink));

    // Your code to run since DOM is loaded and ready
});

/* Terminal Edit Button */

document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById("terminalmodel");
    const closeModal = document.getElementsByClassName("close")[0];
    const editButtons = document.querySelectorAll('.edit');
    const saveChangesButton = document.getElementById('saveChanges');
    let currentRow;

    editButtons.forEach(editButton => {
        editButton.addEventListener('click', (event) => {
            event.preventDefault(); // Prevent default anchor behavior
            currentRow = editButton.closest('tr');
            const cells = currentRow.querySelectorAll('td');
            document.getElementById('terminalName').value = cells[0].innerText;
            document.getElementById('boxNumber').value = cells[1].innerText;
            document.getElementById('quantity').value = cells[2].innerText;
            modal.style.display = "block";
        });
    });

    closeModal.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    saveChangesButton.addEventListener('click', () => {
        const terminalName = document.getElementById('terminalName').value;
        const boxNumber = document.getElementById('boxNumber').value;
        const quantity = document.getElementById('quantity').value;
        const cells = currentRow.querySelectorAll('td');
        cells[0].innerText = terminalName;
        cells[1].innerText = boxNumber;
        cells[2].innerText = quantity;
        modal.style.display = "none";
    });
});